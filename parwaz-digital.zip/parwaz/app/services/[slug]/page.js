import Link from 'next/link';
import { notFound } from 'next/navigation';
import { services, cities } from '../../../lib/data';
export const generateStaticParams = () => services.map(s => ({ slug: s.slug }));
export function generateMetadata({ params }) {
  const s = services.find(x => x.slug === params.slug); if (!s) return {};
  return { title: `${s.title} in Pakistan`, description: `${s.title} by Parwaz Digital, Islamabad and Rawalpindi. ${s.text}`, alternates: { canonical: `/services/${s.slug}` } };
}
export default function Service({ params }) {
  const s = services.find(x => x.slug === params.slug); if (!s) notFound();
  return (<div className="wrap hero"><div style={{fontSize:'3rem'}} aria-hidden>{s.icon}</div><h1>{s.title}</h1>
    <p className="lead">{s.text}</p><Link className="btn" href="/contact">Request a quote</Link>
    <h2 style={{marginTop:60}}>Available in</h2><div className="chips">{cities.map(c => <Link key={c.slug} className="chip" href={`/web-development-company-in-${c.slug}`}>{c.name}</Link>)}</div></div>);
}
