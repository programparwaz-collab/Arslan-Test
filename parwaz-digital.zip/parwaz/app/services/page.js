import Link from 'next/link';
import { services } from '../../lib/data';
export const metadata = { title: 'Web Development, SEO, Shopify, WordPress & AI Services', description: 'Custom web development, SEO, Shopify, WordPress, WooCommerce, AI app development and AI automation services in Pakistan.', alternates: { canonical: '/services' } };
export default function Services() {
  return (<div className="wrap hero"><h1>Our services</h1>
    <div className="grid">{services.map(s => <Link key={s.slug} href={`/services/${s.slug}`} className="card"><div className="i" aria-hidden>{s.icon}</div><h3>{s.title}</h3><p>{s.text}</p></Link>)}</div></div>);
}
