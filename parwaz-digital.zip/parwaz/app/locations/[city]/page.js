import Link from 'next/link';
import { notFound } from 'next/navigation';
import { services, cities } from '../../../lib/data';
export const generateStaticParams = () => cities.map(c => ({ city: c.slug }));
export function generateMetadata({ params }) {
  const c = cities.find(x => x.slug === params.city); if (!c) return {};
  return { title: `Web Development Company in ${c.name}`, description: `Looking for a web development company in ${c.name}? Parwaz Digital offers custom websites, SEO, Shopify, WordPress, WooCommerce and AI automation.`, alternates: { canonical: `/web-development-company-in-${c.slug}` } };
}
export default function City({ params }) {
  const c = cities.find(x => x.slug === params.city); if (!c) notFound();
  return (<>
    <div className="wrap hero"><h1>Web development company in {c.name}</h1>
      <p className="lead">Parwaz Digital helps businesses in {c.name} get online with fast, search-friendly websites, stores and AI tools.</p>
      <Link className="btn" href="/contact">Get a free quote</Link></div>
    <section className="wrap"><h2>Services in {c.name}</h2>
      <div className="grid">{services.map(s => <Link key={s.slug} href={`/services/${s.slug}`} className="card"><div className="i" aria-hidden>{s.icon}</div><h3>{s.title}</h3><p>{s.text}</p></Link>)}</div></section>
    <section className="wrap"><h2>Other cities</h2><div className="chips">{cities.filter(x => x.slug !== c.slug).map(x => <Link key={x.slug} className="chip" href={`/web-development-company-in-${x.slug}`}>{x.name}</Link>)}</div></section>
  </>);
}
