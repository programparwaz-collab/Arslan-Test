import { SITE } from '../../lib/data';
export const metadata = { title: 'Contact Us', description: 'Contact Parwaz Digital for web development, SEO, Shopify, WordPress and AI services. Call 03209115352.', alternates: { canonical: '/contact' } };
export default function Contact() {
  return (<div className="wrap hero"><h1>Contact us</h1>
    <div className="grid">
      <a className="card" href={`tel:${SITE.phone}`}><div className="i" aria-hidden>📞</div><h3>Phone</h3><p>{SITE.phone}</p></a>
      <a className="card" href={`mailto:${SITE.email}`}><div className="i" aria-hidden>✉️</div><h3>Email</h3><p>{SITE.email}</p></a>
      <div className="card"><div className="i" aria-hidden>📍</div><h3>Location</h3><p>Islamabad and Rawalpindi, Pakistan</p></div>
    </div>
    <form action={`mailto:${SITE.email}`} method="post" encType="text/plain">
      <input name="name" placeholder="Your name" required aria-label="Your name" />
      <input name="email" type="email" placeholder="Your email" required aria-label="Your email" />
      <textarea name="message" rows="5" placeholder="Tell us about your project" required aria-label="Message" />
      <button className="btn" type="submit">Send message</button>
    </form></div>);
}
