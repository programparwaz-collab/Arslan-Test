export const metadata = { title: 'About Us', description: 'Parwaz Digital is a web development and AI company serving Islamabad, Rawalpindi, Lahore, Peshawar and all of Pakistan.', alternates: { canonical: '/about' } };
export default function About() {
  const v = [['🚀','Fast delivery','Clear timelines and weekly progress updates.'],['🎯','Results first','Every site is built to rank on Google and bring enquiries.'],['🤝','Ongoing support','We stay with you after launch.']];
  return (<div className="wrap hero"><h1>About Parwaz Digital</h1>
    <p className="lead">We are a web development team based in Islamabad and Rawalpindi. We design, build and grow websites, stores and AI tools for small and mid-size businesses.</p>
    <div className="grid">{v.map(([i,t,p]) => <div key={t} className="card"><div className="i" aria-hidden>{i}</div><h3>{t}</h3><p>{p}</p></div>)}</div></div>);
}
